﻿using CapaDatos.Interface;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CapaNegocio.LN_Entidades
{
    /// <summary>
    /// Clase que representa un repuesto en el sistema.
    /// </summary>
    public class CN_Repuesto
    {
        private Interface_Negocio objIntRepuesto = new Interface_Negocio();
        int id;
        string nombre;
        int cantidad;
        float precio;
        float total;

        /// <summary>
        /// Constructor predeterminado de la clase CN_Repuesto.
        /// Inicializa las propiedades con sus valores por defecto.
        /// </summary>
        public CN_Repuesto()
        {
            id = 0;
            nombre = string.Empty; 
            cantidad = 0;
            precio = 0;
            total = 0;
        }

        /// <summary>
        /// Constructor de la clase CN_Repuesto que permite inicializar todas las propiedades.
        /// </summary>
        public CN_Repuesto(int id, string nombre, int cantidad, float precio, float total)
        {
            this.id = id;
            this.nombre = nombre;
            this.cantidad = cantidad;
            this.precio = precio;
            this.total = total;
        }

        /// <summary>
        /// ID del repuesto.
        /// </summary>
        public int Id 
        { 
            get { return id; }
            set { id = value; }
        }

        /// <summary>
        /// Nombre del repuesto.
        /// </summary>
        public string Nombre
        {
            get { return nombre; }
            set { nombre = value; }
        }

        /// <summary>
        /// Cantidad disponible del repuesto.
        /// </summary>
        public int Cantidad
        { 
            get { return cantidad; } 
            set { cantidad = value; } 
        }

        /// <summary>
        /// Precio unitario del repuesto.
        /// </summary>
        public float Precio
        {
            get { return precio; }
            set { precio = value; }
        }

        /// <summary>
        /// Precio total del repuesto.
        /// </summary>
        public float Total
        { 
            get { return total; } 
            set {  total = value; } 
        }       
    }
}
